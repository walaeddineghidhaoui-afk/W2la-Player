# W2la Player — Android starter project

A native Android music player starter built with Kotlin, Jetpack Compose, and AndroidX Media3. The initial version is monochrome black/white with glass-style translucent cards and scans local audio files only.

## Open and build
1. Install Android Studio (a recent version) and its Android SDK Platform 35.
2. Open the `W2laPlayer` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect an Android phone or start an emulator, then press Run.

Android Studio can generate an APK via **Build > Build APK(s)**. This environment has provided the source project, not a compiled or device-tested APK.

## Current MVP
- Runtime permission for local audio library
- Lists audio tracks from MediaStore
- Search by title, artist, or album
- Playback queue and previous/play/pause/next controls
- Media3 session service for background playback and system media controls
- Black/white glass-style UI

## Notes
- Artwork, waveform animation, favorites persistence, playlist management, true blur/backdrop blur, equalizer/Bass Boost, and advanced settings are planned next steps. The current cards simulate frosted glass with translucent gradients and borders; actual blur depends on device/rendering support and is not yet implemented.
- Equalizer/Bass Boost are not included in this first source milestone.
