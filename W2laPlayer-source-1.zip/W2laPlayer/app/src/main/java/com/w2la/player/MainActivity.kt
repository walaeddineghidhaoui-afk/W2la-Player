package com.w2la.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import android.content.ComponentName
import java.util.Locale

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF151515)
private val White = Color(0xFFF6F6F6)
private val Muted = Color(0xFF999999)

data class LocalSong(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({ controller = controllerFuture?.get() }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        setContent { W2laApp(this, controller) }
    }
}

@Composable
private fun W2laApp(context: Context, controller: MediaController?) {
    var songs by remember { mutableStateOf<List<LocalSong>>(emptyList()) }
    var permissionGranted by remember { mutableStateOf(hasAudioPermission(context)) }
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Home") }
    var currentTitle by remember { mutableStateOf("Choose a song") }
    var currentArtist by remember { mutableStateOf("Your music, your rules") }
    var isPlaying by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) songs = loadSongs(context)
    }
    LaunchedEffect(Unit) {
        if (permissionGranted) songs = loadSongs(context)
        else permissionLauncher.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    LaunchedEffect(controller) {
        while (true) {
            controller?.let {
                isPlaying = it.isPlaying
                it.currentMediaItem?.mediaMetadata?.let { meta ->
                    currentTitle = meta.title?.toString() ?: "Unknown title"
                    currentArtist = meta.artist?.toString() ?: "Unknown artist"
                }
            }
            kotlinx.coroutines.delay(400)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Black, surface = Panel, primary = White, onBackground = White, onSurface = White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF151515), Black, Color(0xFF080808))))) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("W2la Player", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = White)
                        Text("MUSIC IN YOUR WORLD", fontSize = 10.sp, letterSpacing = 2.2.sp, color = Muted)
                    }
                    GlassButton("⌕", Modifier.size(48.dp)) { selectedTab = "Search" }
                }
                Spacer(Modifier.height(20.dp))
                if (selectedTab == "Search" || query.isNotBlank()) {
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search songs, artists, albums…", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = White) }, singleLine = true, shape = RoundedCornerShape(24.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF555555), focusedBorderColor = White, unfocusedContainerColor = Color(0x33111111), focusedContainerColor = Color(0x44111111)))
                    Spacer(Modifier.height(14.dp))
                } else {
                    GlassPanel(Modifier.fillMaxWidth().height(138.dp)) {
                        Row(Modifier.fillMaxSize().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("GOOD MUSIC", fontSize = 11.sp, letterSpacing = 2.sp, color = Muted)
                                Text("Better Days.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Text("All your local music, in one place.", fontSize = 12.sp, color = Muted)
                            }
                            Box(Modifier.size(62.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF777777), Color(0xFF222222)))).border(1.dp, Color(0x99FFFFFF), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(38.dp)) }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("ALL SONGS", "${songs.size} tracks", Icons.Default.LibraryMusic, Modifier.weight(1f)) { selectedTab = "Library" }
                        SummaryCard("PLAYLISTS", "Your collections", Icons.Default.QueueMusic, Modifier.weight(1f)) { selectedTab = "Playlists" }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("ALBUMS", "Explore albums", Icons.Default.Album, Modifier.weight(1f)) { selectedTab = "Albums" }
                        SummaryCard("FOLDERS", "Browse files", Icons.Default.Folder, Modifier.weight(1f)) { selectedTab = "Folders" }
                    }
                    Spacer(Modifier.height(22.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(if (selectedTab == "Home") "Recently added" else selectedTab, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("${songs.size} SONGS", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(10.dp))
                if (!permissionGranted) {
                    GlassPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text("Music access needed", fontWeight = FontWeight.Bold); Text("Allow W2la Player to scan audio files stored on your phone.", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(10.dp)); Button(onClick = { permissionLauncher.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE) }) { Text("Allow access") } } }
                } else if (songs.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.LibraryMusic, null, tint = Muted, modifier = Modifier.size(44.dp)); Spacer(Modifier.height(10.dp)); Text("No music found", fontWeight = FontWeight.SemiBold); Text("Add audio files to your phone and refresh.", color = Muted, fontSize = 12.sp) } }
                } else {
                    val visibleSongs = songs.filter { "${it.title} ${it.artist} ${it.album}".contains(query, ignoreCase = true) }
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        itemsIndexed(visibleSongs, key = { _, song -> song.id }) { index, song ->
                            SongRow(song, index, controller?.currentMediaItem?.mediaId == song.id.toString()) {
                                currentTitle = song.title; currentArtist = song.artist
                                controller?.let { player ->
                                    val mediaItems = songs.map { item -> MediaItem.Builder().setMediaId(item.id.toString()).setUri(item.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(item.title).setArtist(item.artist).setAlbumTitle(item.album).build()).build() }
                                    player.setMediaItems(mediaItems, songs.indexOf(song), 0L); player.prepare(); player.play()
                                }
                            }
                        }
                    }
                }
                if (songs.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    GlassPanel(Modifier.fillMaxWidth().height(76.dp)) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFF777777), Color(0xFF202020)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Album, null, tint = White, modifier = Modifier.size(27.dp)) }
                            Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(currentTitle, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(currentArtist, color = Muted, fontSize = 12.sp, maxLines = 1) }
                            IconButton(onClick = { controller?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = White) }
                            IconButton(onClick = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(30.dp)) }
                            IconButton(onClick = { controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = White) }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                GlassPanel(Modifier.fillMaxWidth().height(64.dp)) {
                    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                        NavItem("Home", selectedTab, Icons.Default.Home) { selectedTab = "Home"; query = "" }
                        NavItem("Library", selectedTab, Icons.Default.LibraryMusic) { selectedTab = "Library"; query = "" }
                        NavItem("Playlists", selectedTab, Icons.Default.QueueMusic) { selectedTab = "Playlists"; query = "" }
                        NavItem("Search", selectedTab, Icons.Default.Search) { selectedTab = "Search" }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.shadow(12.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0x442F2F2F), Color(0x22101010), Color(0x33262626)))).border(1.dp, Brush.linearGradient(listOf(Color(0xAAFFFFFF), Color(0x22555555), Color(0x66777777))), RoundedCornerShape(22.dp)), content = content)
}

@Composable private fun GlassButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.shadow(8.dp, CircleShape).clip(CircleShape).background(Color(0x33222222)).border(1.dp, Color(0x66FFFFFF), CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Text(label, color = White, fontSize = 29.sp) }
}

@Composable private fun SummaryCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    GlassPanel(modifier.height(76.dp)) {
        Row(Modifier.fillMaxSize().clickable(onClick = onClick).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, fontSize = 10.sp, letterSpacing = 1.sp, color = Muted); Spacer(Modifier.height(4.dp)); Text(subtitle, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            Icon(icon, null, tint = White, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable private fun SongRow(song: LocalSong, index: Int, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (selected) Color(0x443F3F3F) else Color.Transparent).border(if (selected) 1.dp else 0.dp, if (selected) Color(0x88FFFFFF) else Color.Transparent, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(String.format(Locale.getDefault(), "%02d", index + 1), color = Muted, fontSize = 11.sp, modifier = Modifier.width(28.dp))
        Box(Modifier.size(45.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF777777), Color(0xFF242424)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Album, null, tint = White, modifier = Modifier.size(24.dp)) }
        Column(Modifier.weight(1f).padding(start = 11.dp)) { Text(song.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, color = White); Text(song.artist, fontSize = 12.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        Text(formatDuration(song.duration), color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun NavItem(label: String, selected: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (selected == label) White else Muted, modifier = Modifier.size(21.dp))
        Text(label, fontSize = 10.sp, color = if (selected == label) White else Muted)
    }
}

private fun hasAudioPermission(context: Context): Boolean {
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

private fun loadSongs(context: Context): List<LocalSong> {
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION)
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    val result = mutableListOf<LocalSong>()
    var cursor: Cursor? = null
    try {
        cursor = context.contentResolver.query(collection, projection, selection, null, sortOrder)
        cursor?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result += LocalSong(id, c.getString(titleCol) ?: "Unknown title", c.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist", c.getString(albumCol) ?: "Unknown album", ContentUris.withAppendedId(collection, id), c.getLong(durationCol))
            }
        }
    } catch (_: Exception) { }
    return result
}

private fun formatDuration(ms: Long): String { val total = ms / 1000; return String.format(Locale.getDefault(), "%d:%02d", total / 60, total % 60) }
